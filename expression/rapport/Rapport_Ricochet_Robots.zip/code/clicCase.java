@Override
public void clicSurCase(Case casePlateau){
	robotAJouer();
}