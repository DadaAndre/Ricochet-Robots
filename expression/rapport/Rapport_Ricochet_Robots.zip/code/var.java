public final String chaine1 = "9,8,8,12,9,...,0,4,9"; //haut, gauche
public final String chaine2 = "8,12,9,8,8,...,8,0,0,4"; //haut droit
public final String chaine3 = "6,1,0,0,0,...,2,2,6"; //bas droit
public final String chaine4 = "1,0,0,0,0,...,6,3,2,2"; //bas gauche