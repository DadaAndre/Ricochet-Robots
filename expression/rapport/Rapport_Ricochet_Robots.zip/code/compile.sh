./build.sh run
./build.sh run --args "300"